from setuptools import setup

setup(name='udacityds_distributions_jacob',
      version='0.1',
      description='Gaussian distributions',
      packages=['udacityds_distributions_jacob'],
      zip_safe=False)
